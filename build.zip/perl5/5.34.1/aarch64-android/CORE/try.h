LIBTEST_42 {
 global:
  foo;
 local: *;
 };
